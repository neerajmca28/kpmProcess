<?php

	$this->load->view('include/header');
	$this->load->view('include/headerMenu');
	$this->load->view('include/leftMenu');
	$this->load->view($body);
	$this->load->view('include/footer');

?>	