
<div class="layout-main">
  <div class="layout-sidebar">
    <div class="layout-sidebar-backdrop"></div>
    <div class="layout-sidebar-body">
      <div class="custom-scrollbar">
        <nav id="sidenav" class="sidenav-collapse collapse">
          <ul class="sidenav" id="nav1">
      
            <li class="sidenav-item">
               <a href="<?php echo base_url().'support' ?>">
                <span class="badge badge-success"></span>
                <span class="sidenav-icon icon icon-cart-plus "></span>
                <span class="sidenav-label">New Device Additon</span>
              </a>
            </li>
            <li class="sidenav-item">
               <a href="<?php echo base_url().'support/vehicleNoChange' ?>">
                <span class="badge badge-success"></span>
                <span class="sidenav-icon icon icon-refresh"></span>
                <span class="sidenav-label">Vehicle Change</span>
              </a>
            </li>
	<?php// if($_SESSION['user_name']=='rahul123')
	//{
		?><li class="sidenav-item">
               <a href="<?php echo base_url().'support/imeiSelect' ?>">
                <span class="badge badge-success"></span>
                <span class="sidenav-icon icon icon-refresh"></span>
                <span class="sidenav-label">IMEI Select</span>
              </a>
            </li>
	<!-- <?php }?> -->
            
          </ul>
        </nav>
      </div>
    </div>
  </div>
